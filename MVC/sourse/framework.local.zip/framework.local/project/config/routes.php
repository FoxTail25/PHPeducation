<?php
	use \Core\Route;
	
	return [
		new Route('/hello/', 'hello', 'index'), // route for the welcome page, can be deleted
	];
	
